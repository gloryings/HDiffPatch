// ParseProperties.h

#ifndef ZIP7_INC_PARSE_PROPERTIES_H
#define ZIP7_INC_PARSE_PROPERTIES_H

#endif
