#define IDD_MEM                 7800

#define IDX_MEM_SAVE_LIMIT      7801
#define IDX_MEM_REMEMBER        7802
#define IDG_MEM_ACTION          7803

#define IDR_MEM_ACTION_ALLOW    7820
#define IDR_MEM_ACTION_SKIP_ARC 7821

#define IDT_MEM_MESSAGE         101
#define IDE_MEM_SPIN_EDIT       110
#define IDC_MEM_SPIN            111
#define IDT_MEM_GB              112
