/* Precomp.h -- Precomp
2024-01-23 : Igor Pavlov : Public domain */

// #ifndef ZIP7_INC_PRECOMP_LOC_H
// #define ZIP7_INC_PRECOMP_LOC_H

#if defined(_MSC_VER) && _MSC_VER >= 1800
#pragma warning(disable : 4464) // relative include path contains '..'
#endif

#include "../../Precomp.h"

// #endif
